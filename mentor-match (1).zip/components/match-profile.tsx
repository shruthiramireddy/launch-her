import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, MessageSquare } from "lucide-react"

interface MatchProfileProps {
  user: {
    id: string
    name: string
    role: string
    bio: string
    pronouns?: string
    company?: string
    avatar?: string
    skills: string[]
    matchPercentage: number
    alignmentSummary: string
  }
}

export function MatchProfile({ user }: MatchProfileProps) {
  return (
    <Card className="overflow-hidden">
      <div className="h-2 bg-pink-500"></div>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={user.avatar || "/placeholder.svg?height=64&width=64"} alt={user.name} />
              <AvatarFallback>
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-xl">
                {user.name}{" "}
                {user.pronouns && <span className="text-sm font-normal text-gray-500">({user.pronouns})</span>}
              </CardTitle>
              <CardDescription>{user.role}</CardDescription>
              {user.company && (
                <div className="mt-1 inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                  {user.company}
                </div>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1">
              <span className="text-sm font-medium">{user.matchPercentage}% Match</span>
              <div className="h-2 w-2 rounded-full bg-green-500"></div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-sm text-gray-700">{user.bio}</p>
        </div>

        <div>
          <h4 className="mb-2 text-sm font-medium text-gray-500">Skills & Expertise</h4>
          <div className="flex flex-wrap gap-2">
            {user.skills.map((skill) => (
              <span key={skill} className="rounded-full bg-pink-100 px-2.5 py-0.5 text-xs font-medium text-pink-800">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="rounded-lg bg-gray-50 p-3">
          <h4 className="mb-1 text-sm font-medium">Why we matched you</h4>
          <p className="text-sm text-gray-600">{user.alignmentSummary}</p>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Link href="/dashboard/meetings" className="flex-1">
          <Button className="w-full bg-pink-500 hover:bg-pink-600">
            <Calendar className="mr-2 h-4 w-4" /> Schedule Meeting
          </Button>
        </Link>
        <Link href="/dashboard/messages" className="flex-1">
          <Button variant="outline" className="w-full">
            <MessageSquare className="mr-2 h-4 w-4" /> Message
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
