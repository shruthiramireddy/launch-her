"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { submitOnboardingData } from "@/app/actions/onboarding-actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, ArrowRight, FileUp, Loader2, Users } from "lucide-react"

const formSchema = z.object({
  // Background & Identity
  role: z.enum(["mentee", "mentor"], {
    required_error: "Please select a role",
  }),
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters",
  }),
  email: z.string().email({
    message: "Please enter a valid email address",
  }),
  linkedinProfile: z.string().optional(),
  location: z.string().min(2, {
    message: "Please enter your current location",
  }),
  careerStage: z.string({
    required_error: "Please select your career stage",
  }),
  industries: z.array(z.string()).min(1, {
    message: "Please select at least one industry",
  }),
  languages: z.array(z.string()).min(1, {
    message: "Please select at least one language",
  }),

  // Goals & Needs
  shortTermGoals: z.string().min(10, {
    message: "Short-term goals must be at least 10 characters",
  }),
  longTermGoals: z.string().min(10, {
    message: "Long-term goals must be at least 10 characters",
  }),
  helpAreas: z.array(z.string()).min(1, {
    message: "Please select at least one area you need help with",
  }),

  // Additional fields
  resume: z.any().optional(),
})

export default function OnboardingPage() {
  const [step, setStep] = useState(1)
  const [resumeFile, setResumeFile] = useState<File | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      role: "mentee",
      fullName: "",
      email: "",
      linkedinProfile: "",
      location: "",
      careerStage: "",
      industries: [],
      languages: [],
      shortTermGoals: "",
      longTermGoals: "",
      helpAreas: [],
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    try {
      // Call the server action to submit the data
      const result = await submitOnboardingData(values)

      if (result.success) {
        toast({
          title: "Profile completed!",
          description: "We're finding your perfect match...",
        })

        // Redirect to dashboard
        router.push("/dashboard")
      } else {
        toast({
          title: "Submission failed",
          description: result.error || "Please try again",
          variant: "destructive",
        })
        setIsSubmitting(false)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      toast({
        title: "Submission failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setResumeFile(e.target.files[0])
      form.setValue("resume", e.target.files[0])
    }
  }

  const industries = [
    { id: "tech", label: "Technology" },
    { id: "healthcare", label: "Healthcare" },
    { id: "education", label: "Education" },
    { id: "law", label: "Law" },
    { id: "finance", label: "Finance" },
    { id: "nonprofit", label: "Nonprofit" },
    { id: "media", label: "Media" },
    { id: "retail", label: "Retail" },
    { id: "manufacturing", label: "Manufacturing" },
    { id: "consulting", label: "Consulting" },
    { id: "government", label: "Government" },
    { id: "other", label: "Other" },
  ]

  const languages = [
    { id: "english", label: "English" },
    { id: "spanish", label: "Spanish" },
    { id: "french", label: "French" },
    { id: "german", label: "German" },
    { id: "chinese", label: "Chinese" },
    { id: "japanese", label: "Japanese" },
    { id: "korean", label: "Korean" },
    { id: "arabic", label: "Arabic" },
    { id: "hindi", label: "Hindi" },
    { id: "portuguese", label: "Portuguese" },
    { id: "russian", label: "Russian" },
    { id: "other", label: "Other" },
  ]

  const helpAreas = [
    { id: "resume-review", label: "Resume review" },
    { id: "career-advice", label: "Career advice" },
    { id: "interview-prep", label: "Interview prep" },
    { id: "networking", label: "Networking" },
    { id: "skill-development", label: "Skill development" },
    { id: "work-life-balance", label: "Work-life balance" },
    { id: "leadership", label: "Leadership" },
    { id: "grad-school", label: "Graduate school advice" },
    { id: "industry-transition", label: "Industry transition" },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6 text-pink-500" />
            <span className="text-xl font-bold">MentorMatch</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost">Cancel</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1 bg-gray-50 py-12">
        <div className="container max-w-2xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Let's get to know you</h1>
            <p className="text-gray-500">Complete this short form to help us find your perfect match</p>
          </div>

          <div className="mb-8 flex justify-between">
            <div className="flex items-center gap-2">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full ${
                  step >= 1 ? "bg-pink-500 text-white" : "bg-gray-200 text-gray-500"
                }`}
              >
                1
              </div>
              <span className={step >= 1 ? "font-medium" : "text-gray-500"}>Background & Identity</span>
            </div>
            <div className="h-0.5 flex-1 self-center mx-4 bg-gray-200">
              <div
                className="h-full bg-pink-500"
                style={{ width: `${step > 1 ? 100 : 0}%`, transition: "width 0.3s ease-in-out" }}
              ></div>
            </div>
            <div className="flex items-center gap-2">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full ${
                  step >= 2 ? "bg-pink-500 text-white" : "bg-gray-200 text-gray-500"
                }`}
              >
                2
              </div>
              <span className={step >= 2 ? "font-medium" : "text-gray-500"}>Goals & Needs</span>
            </div>
            <div className="h-0.5 flex-1 self-center mx-4 bg-gray-200">
              <div
                className="h-full bg-pink-500"
                style={{ width: `${step > 2 ? 100 : 0}%`, transition: "width 0.3s ease-in-out" }}
              ></div>
            </div>
            <div className="flex items-center gap-2">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full ${
                  step >= 3 ? "bg-pink-500 text-white" : "bg-gray-200 text-gray-500"
                }`}
              >
                3
              </div>
              <span className={step >= 3 ? "font-medium" : "text-gray-500"}>Resume</span>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {step === 1 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Background & Identity</CardTitle>
                    <CardDescription>Tell us about yourself</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>I am looking to be a:</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="mentee" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Mentee (Little) - I'm seeking guidance and support
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="mentor" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Mentor (Big) - I want to share my knowledge and experience
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="name@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="linkedinProfile"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>LinkedIn Profile (optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://linkedin.com/in/yourprofile" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Current Location (City, State/Country)</FormLabel>
                          <FormControl>
                            <Input placeholder="San Francisco, CA" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="careerStage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>What stage are you in your career/education?</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your career stage" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="high-school">High school student</SelectItem>
                              <SelectItem value="undergraduate">Undergraduate</SelectItem>
                              <SelectItem value="graduate">Graduate student</SelectItem>
                              <SelectItem value="early-career">Early career professional</SelectItem>
                              <SelectItem value="mid-career">Mid-career</SelectItem>
                              <SelectItem value="senior">Senior professional</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="industries"
                      render={() => (
                        <FormItem>
                          <div className="mb-4">
                            <FormLabel className="text-base">Field/Industry of Interest</FormLabel>
                            <FormDescription>
                              Select all industries you're interested in or have experience with.
                            </FormDescription>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {industries.map((industry) => (
                              <FormField
                                key={industry.id}
                                control={form.control}
                                name="industries"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={industry.id}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(industry.id)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...field.value, industry.id])
                                              : field.onChange(field.value?.filter((value) => value !== industry.id))
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal">{industry.label}</FormLabel>
                                    </FormItem>
                                  )
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="languages"
                      render={() => (
                        <FormItem>
                          <div className="mb-4">
                            <FormLabel className="text-base">Preferred language(s) for communication</FormLabel>
                            <FormDescription>Select all languages you're comfortable communicating in.</FormDescription>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {languages.map((language) => (
                              <FormField
                                key={language.id}
                                control={form.control}
                                name="languages"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={language.id}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(language.id)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...field.value, language.id])
                                              : field.onChange(field.value?.filter((value) => value !== language.id))
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal">{language.label}</FormLabel>
                                    </FormItem>
                                  )
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button type="button" onClick={() => setStep(2)} className="bg-pink-500 hover:bg-pink-600">
                      Next
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              )}

              {step === 2 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Goals & Needs</CardTitle>
                    <CardDescription>Help us understand what you're looking for</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="shortTermGoals"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>What are your short-term career goals?</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="What do you hope to achieve in the next 6-12 months?"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Examples: Land a specific role, improve a particular skill, complete a certification
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="longTermGoals"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>What are your long-term dreams or career aspirations?</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Where do you see yourself in 5+ years?"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Examples: Reach a leadership position, start your own business, become an expert in your
                            field
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="helpAreas"
                      render={() => (
                        <FormItem>
                          <div className="mb-4">
                            <FormLabel className="text-base">What areas do you want help with?</FormLabel>
                            <FormDescription>
                              Select all areas where you'd like guidance or can offer support.
                            </FormDescription>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {helpAreas.map((area) => (
                              <FormField
                                key={area.id}
                                control={form.control}
                                name="helpAreas"
                                render={({ field }) => {
                                  return (
                                    <FormItem key={area.id} className="flex flex-row items-start space-x-3 space-y-0">
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(area.id)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...field.value, area.id])
                                              : field.onChange(field.value?.filter((value) => value !== area.id))
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal">{area.label}</FormLabel>
                                    </FormItem>
                                  )
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => setStep(1)}>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back
                    </Button>
                    <Button type="button" onClick={() => setStep(3)} className="bg-pink-500 hover:bg-pink-600">
                      Next
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              )}

              {step === 3 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Resume Upload</CardTitle>
                    <CardDescription>Upload your resume to help with matching</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-12">
                      <FileUp className="h-12 w-12 text-gray-400 mb-4" />
                      <p className="text-sm text-gray-500 mb-2">Drag and drop your resume here, or click to browse</p>
                      <p className="text-xs text-gray-400 mb-4">Supports PDF, DOCX (Max 5MB)</p>
                      <Input
                        type="file"
                        id="resume"
                        className="hidden"
                        accept=".pdf,.docx"
                        onChange={handleFileChange}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById("resume")?.click()}
                      >
                        Browse Files
                      </Button>
                      {resumeFile && (
                        <div className="mt-4 flex items-center gap-2 text-sm">
                          <FileUp className="h-4 w-4 text-pink-500" />
                          <span>{resumeFile.name}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-500">
                      Your resume helps us understand your background and make better matches. We'll never share it
                      without your permission.
                    </p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button type="button" variant="outline" onClick={() => setStep(2)}>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back
                    </Button>
                    <Button type="submit" className="bg-pink-500 hover:bg-pink-600" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        "Complete Profile"
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </form>
          </Form>
        </div>
      </main>
    </div>
  )
}
