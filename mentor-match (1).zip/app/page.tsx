import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Award, Calendar, MessageSquare, Users } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6 text-pink-500" />
            <span className="text-xl font-bold">MentorMatch</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="#features" className="text-sm font-medium hover:text-pink-500">
              Features
            </Link>
            <Link href="#how-it-works" className="text-sm font-medium hover:text-pink-500">
              How It Works
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:text-pink-500">
              Testimonials
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline" className="hidden sm:flex">
                Log In
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-pink-500 hover:bg-pink-600">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-pink-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Meaningful Mentorship Connections
                  </h1>
                  <p className="max-w-[600px] text-gray-500 md:text-xl">
                    Not just random pairings. Our smart matching engine connects mentees with mentors based on career
                    goals, interests, values, and backgrounds.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/signup?role=mentee">
                    <Button className="bg-pink-500 hover:bg-pink-600">
                      Find a Mentor
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/signup?role=mentor">
                    <Button variant="outline">Become a Mentor</Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <img
                  alt="Mentorship illustration"
                  className="rounded-lg object-cover"
                  height="400"
                  src="/placeholder.svg?height=400&width=500"
                  width="500"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-pink-100 px-3 py-1 text-sm text-pink-500">Features</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                  Everything you need for successful mentorship
                </h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl">
                  Our platform provides all the tools needed to foster meaningful, lasting connections.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <Users className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-bold">Smart Matching</h3>
                <p className="text-center text-gray-500">
                  Our NLP-powered algorithm matches mentors and mentees based on compatibility, shared industry, values,
                  and goals.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <Calendar className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-bold">Meeting Scheduler</h3>
                <p className="text-center text-gray-500">
                  Built-in scheduling tool for coordinating sessions with optional reminders to keep you on track.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <MessageSquare className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-bold">Conversation Threads</h3>
                <p className="text-center text-gray-500">
                  View past messages or shared goals in one place with dedicated notebooks for collaboration.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-pink-500"
                  >
                    <path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold">Meeting Notes</h3>
                <p className="text-center text-gray-500">
                  Dedicated tab to reflect on each meeting and log progress over time.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-pink-500"
                  >
                    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z" />
                    <path d="M8 7h6" />
                    <path d="M8 11h8" />
                    <path d="M8 15h6" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold">Resume Upload</h3>
                <p className="text-center text-gray-500">
                  Upload your resume to provide context and help with better matching.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                <div className="rounded-full bg-pink-100 p-3">
                  <Award className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-bold">Gamification</h3>
                <p className="text-center text-gray-500">
                  Earn badges for skill-based contributions, time spent mentoring, and consistent weekly check-ins.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="how-it-works" className="w-full py-12 md:py-24 lg:py-32 bg-pink-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-pink-100 px-3 py-1 text-sm text-pink-500">How It Works</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                  Simple steps to meaningful mentorship
                </h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl">
                  Our platform makes it easy to find the perfect mentor or mentee match.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
              <div className="flex flex-col items-center space-y-2 rounded-lg border bg-white p-6 shadow-sm">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pink-100 text-xl font-bold text-pink-500">
                  1
                </div>
                <h3 className="text-xl font-bold">Complete Survey</h3>
                <p className="text-center text-gray-500">
                  Fill out our onboarding survey with your career info, goals, and upload your resume.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border bg-white p-6 shadow-sm">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pink-100 text-xl font-bold text-pink-500">
                  2
                </div>
                <h3 className="text-xl font-bold">Get Matched</h3>
                <p className="text-center text-gray-500">
                  Our algorithm finds your ideal mentor or mentee based on compatibility.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border bg-white p-6 shadow-sm">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pink-100 text-xl font-bold text-pink-500">
                  3
                </div>
                <h3 className="text-xl font-bold">Start Connecting</h3>
                <p className="text-center text-gray-500">
                  Schedule meetings, share resources, and track your progress together.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="testimonials" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-pink-100 px-3 py-1 text-sm text-pink-500">Testimonials</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Success stories from our community</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl">
                  Hear from mentors and mentees who have found meaningful connections on our platform.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col justify-between space-y-4 rounded-lg border p-6 shadow-sm">
                <div className="space-y-2">
                  <p className="text-gray-500">
                    "Finding a mentor who truly understood my career goals was a game-changer. The matching algorithm
                    really works!"
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div>
                    <p className="text-sm font-medium">Sarah Johnson</p>
                    <p className="text-sm text-gray-500">Marketing Specialist</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col justify-between space-y-4 rounded-lg border p-6 shadow-sm">
                <div className="space-y-2">
                  <p className="text-gray-500">
                    "As a mentor, I've been able to give back in a meaningful way. The scheduling tools make it easy to
                    stay consistent."
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div>
                    <p className="text-sm font-medium">David Chen</p>
                    <p className="text-sm text-gray-500">Senior Developer</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col justify-between space-y-4 rounded-lg border p-6 shadow-sm">
                <div className="space-y-2">
                  <p className="text-gray-500">
                    "The meeting notes feature has been invaluable for tracking my progress and growth over time."
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                  <div>
                    <p className="text-sm font-medium">Maya Patel</p>
                    <p className="text-sm text-gray-500">UX Designer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-pink-500 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">
                  Ready to start your mentorship journey?
                </h2>
                <p className="max-w-[900px] md:text-xl">Join our community of mentors and mentees today.</p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/signup?role=mentee">
                  <Button className="bg-white text-pink-500 hover:bg-gray-100">Find a Mentor</Button>
                </Link>
                <Link href="/signup?role=mentor">
                  <Button variant="outline" className="border-white text-white hover:bg-pink-600">
                    Become a Mentor
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-white py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6 text-pink-500" />
            <span className="text-xl font-bold">MentorMatch</span>
          </div>
          <p className="text-center text-sm text-gray-500 md:text-left">
            © {new Date().getFullYear()} MentorMatch. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-gray-500 hover:text-pink-500">
              Terms
            </Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-pink-500">
              Privacy
            </Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-pink-500">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
