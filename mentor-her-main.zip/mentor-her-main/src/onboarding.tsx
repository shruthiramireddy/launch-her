// src/pages/onboarding.tsx

import React, { useState, useEffect, ChangeEvent } from "react"; // Changed React import
import Link from "next/link";
import { useRouter } from "next/router";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

// Shadcn UI components
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
// import { useToast } from "@/components/ui/use-toast"; // REMOVE THIS OLD IMPORT
import { toast as sonnerToast } from "sonner"; // IMPORT SONNER'S TOAST
import { ArrowLeft, ArrowRight, FileUp, Loader2, Users } from "lucide-react";

import { supabase } from "@/lib/supabaseClient";

// Zod Schema
const formSchema = z.object({
  role: z.enum(["mentee", "mentor"], {
    required_error: "Please select your role.",
  }),
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters.",
  }),
  linkedinProfile: z.string().url({ message: "Please enter a valid URL (e.g., https://linkedin.com/...)." }).optional().or(z.literal('')),
  location: z.string().min(2, {
    message: "Please enter your current location.",
  }),
  careerStage: z.string({
    required_error: "Please select your career stage.",
  }),
  industries: z.array(z.string()).min(1, {
    message: "Please select at least one industry.",
  }),
  languages: z.array(z.string()).min(1, {
    message: "Please select at least one language.",
  }),
  shortTermGoals: z.string().min(10, {
    message: "Short-term goals must be at least 10 characters.",
  }),
  longTermGoals: z.string().min(10, {
    message: "Long-term goals must be at least 10 characters.",
  }),
  helpAreas: z.array(z.string()).min(1, {
    message: "Please select at least one area.",
  }),
  resume: z.custom<File>((val) => val === undefined || val instanceof File, {
    message: "Please upload a valid resume file.",
  }).optional(),
});

type OnboardingFormValues = z.infer<typeof formSchema>;

interface SelectableItem { id: string; label: string; }
const industriesData: SelectableItem[] = [
    { id: "tech", label: "Technology" }, { id: "healthcare", label: "Healthcare" },
    { id: "education", label: "Education" }, { id: "law", label: "Law" },
    { id: "finance", label: "Finance" }, { id: "nonprofit", label: "Nonprofit" },
    { id: "media", label: "Media" }, { id: "retail", label: "Retail" },
    { id: "manufacturing", label: "Manufacturing" }, { id: "consulting", label: "Consulting" },
    { id: "government", label: "Government" }, { id: "other", label: "Other" },
];
const languagesData: SelectableItem[] = [
    { id: "english", label: "English" }, { id: "spanish", label: "Spanish" },
    { id: "french", label: "French" }, { id: "german", label: "German" },
    { id: "chinese", label: "Chinese (Mandarin)"}, { id: "hindi", label: "Hindi"},
    { id: "arabic", label: "Arabic"}, { id: "portuguese", label: "Portuguese"},
    { id: "russian", label: "Russian"}, { id: "japanese", label: "Japanese"},
    { id: "other", label: "Other"},
];
const helpAreasData: SelectableItem[] = [
    { id: "resume-review", label: "Resume Review" }, { id: "career-advice", label: "Career Advice" },
    { id: "interview-prep", label: "Interview Prep" }, { id: "networking", label: "Networking Strategies" },
    { id: "skill-development", label: "Skill Development" }, { id: "work-life-balance", label: "Work-Life Balance" },
    { id: "leadership", label: "Leadership Skills" }, { id: "grad-school", label: "Graduate School Advice" },
    { id: "industry-transition", label: "Industry Transition" }, {id: "public-speaking", label: "Public Speaking"},
    {id: "salary-negotiation", label: "Salary Negotiation"}, {id: "entrepreneurship", label: "Entrepreneurship"},
];
const careerStageOptions: SelectableItem[] = [
    { id: "student-high-school", label: "High School Student" },
    { id: "student-undergrad", label: "Undergraduate Student" },
    { id: "student-grad", label: "Graduate Student" },
    { id: "entry-level", label: "Entry Level (0-2 years exp.)" },
    { id: "early-career", label: "Early Career (2-5 years exp.)" },
    { id: "mid-career", label: "Mid-Career (5-10 years exp.)" },
    { id: "senior-career", label: "Senior Career (10+ years exp.)" },
    { id: "career-changer", label: "Career Changer" },
    { id: "executive-level", label: "Executive Level"},
    { id: "other", label: "Other" },
];

export default function OnboardingPage() {
  const [step, setStep] = useState(1);
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();
  // const { toast } = useToast(); // REMOVED old useToast

  const form = useForm<OnboardingFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      role: "mentee",
      fullName: "",
      linkedinProfile: "",
      location: "",
      careerStage: undefined,
      industries: [],
      languages: [],
      shortTermGoals: "",
      longTermGoals: "",
      helpAreas: [],
      resume: undefined,
    },
  });

  useEffect(() => {
    const checkUserAndPrefill = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        sonnerToast.error("Authentication Required", { description: "Please log in to complete onboarding." });
        router.push('/auth/login');
      } else {
        if (user.user_metadata?.full_name && !form.getValues("fullName")) {
          form.setValue("fullName", user.user_metadata.full_name);
        }
      }
    };
    checkUserAndPrefill();
  }, [router, form]); // Removed toast from dependency array

  async function onSubmit(values: OnboardingFormValues) {
    setIsSubmitting(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !user.email) {
      sonnerToast.error("Authentication Error", { description: "User session not found. Please log in again." });
      setIsSubmitting(false);
      router.push('/auth/login');
      return;
    }

    const formData = new FormData();
    const formValuesWithoutResume = { ...values, resume: undefined, userId: user.id, email: user.email };
    formData.append('jsonData', JSON.stringify(formValuesWithoutResume));
    if (resumeFile) {
      formData.append('resumeFile', resumeFile, resumeFile.name);
    }

    try {
      const response = await fetch('/api/onboarding/submit', { method: 'POST', body: formData });
      const result = await response.json();
      if (response.ok && result.success) {
        sonnerToast.success("Profile Completed!", { description: result.message || "Welcome! We're excited to help you find your match." });
        router.push("/dashboard");
      } else {
        sonnerToast.error("Submission Failed", { description: result.error || "An error occurred. Please review your information and try again." });
      }
    } catch (error) {
      console.error("Client-side error submitting form:", error);
      sonnerToast.error("Submission Failed", { description: "An unexpected error occurred. Please try again." });
    } finally {
      setIsSubmitting(false);
    }
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        form.setError("resume", { type: "manual", message: "Resume must be less than 5MB." });
        sonnerToast.error("File too large", { description: "Resume should be less than 5MB." });
        setResumeFile(null); e.target.value = ''; return;
      }
      const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword'];
      if (!allowedTypes.includes(file.type)) {
        form.setError("resume", { type: "manual", message: "Only PDF, DOC, or DOCX files are allowed." });
        sonnerToast.error("Invalid file type", { description: "Only PDF, DOC, or DOCX files are accepted." });
        setResumeFile(null); e.target.value = ''; return;
      }
      setResumeFile(file);
      form.setValue("resume", file, { shouldValidate: true });
      form.clearErrors("resume");
    } else {
      setResumeFile(null);
      form.setValue("resume", undefined, { shouldValidate: true });
    }
  };

  const handleNextStep = async () => {
    let fieldsToValidate: (keyof OnboardingFormValues)[] = [];
    if (step === 1) {
      fieldsToValidate = ["role", "fullName", "location", "careerStage", "industries", "languages"];
      if (form.getValues("linkedinProfile")) fieldsToValidate.push("linkedinProfile");
    } else if (step === 2) {
      fieldsToValidate = ["shortTermGoals", "longTermGoals", "helpAreas"];
    }

    if (fieldsToValidate.length > 0) {
      const isValid = await form.trigger(fieldsToValidate);
      if (isValid) setStep((s) => s + 1);
      else sonnerToast.error("Incomplete Information", { description: "Please fill out all required fields in this section correctly." });
    } else setStep((s) => s + 1);
  };

  const handlePrevStep = () => setStep((s) => s - 1);

  return (
    <div className="flex min-h-screen flex-col bg-gray-100">
      <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <Users className="h-6 w-6 text-pink-500" />
            <span className="text-xl font-bold text-gray-800">MentorMatch</span>
          </Link>
          <Link href="/">
            <Button variant="ghost">Cancel</Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 py-8 md:py-12">
        <div className="container max-w-2xl px-4 md:px-6">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Let&apos;s Get to Know You</h1>
            <p className="mt-2 text-lg text-gray-600">
              Complete this form to help us find your perfect mentor or mentee match.
            </p>
          </div>

          {/* Stepper UI */}
          <div className="mb-10 flex items-center justify-center space-x-1 sm:space-x-2 md:space-x-4 p-4">
             {["Background", "Goals & Needs", "Resume"].map((label, index) => {
              const stepNumber = index + 1;
              const isActive = step === stepNumber;
              const isCompleted = step > stepNumber;
              return (
                <React.Fragment key={stepNumber}> {/* Changed key to stepNumber for React.Fragment */}
                  <div className="flex flex-col items-center text-center">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-full border-2 font-semibold transition-all duration-300
                        ${isActive ? "border-pink-500 bg-pink-500 text-white scale-110" : ""}
                        ${isCompleted ? "border-pink-500 bg-pink-500 text-white" : ""}
                        ${!isActive && !isCompleted ? "border-gray-300 bg-white text-gray-500" : ""}`}
                    >
                      {isCompleted ? "✓" : stepNumber}
                    </div>
                    <p className={`mt-2 max-w-[100px] text-xs sm:text-sm font-medium transition-colors duration-300 ${isActive || isCompleted ? "text-pink-600" : "text-gray-500"}`}>
                      {label}
                    </p>
                  </div>
                  {index < 2 && (
                    <div className={`h-1 flex-1 rounded transition-colors duration-300 ${step > stepNumber ? "bg-pink-500" : "bg-gray-300"}`}></div>
                  )}
                </React.Fragment>
              );
            })}
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Step 1: Background & Identity */}
              {step === 1 && (
                <Card className="shadow-lg">
                  <CardHeader> <CardTitle>Step 1: Background & Identity</CardTitle> <CardDescription>Tell us a bit about yourself.</CardDescription> </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField control={form.control} name="role" render={({ field }) => ( <FormItem className="space-y-3"> <FormLabel className="font-semibold">I want to be a:*</FormLabel> <FormControl><RadioGroup onValueChange={field.onChange} defaultValue={field.value} className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-6"> <FormItem className="flex items-center space-x-3"> <FormControl><RadioGroupItem value="mentee" id="role-mentee" /></FormControl> <FormLabel htmlFor="role-mentee" className="font-normal cursor-pointer">Mentee (Seeking Guidance)</FormLabel> </FormItem> <FormItem className="flex items-center space-x-3"> <FormControl><RadioGroupItem value="mentor" id="role-mentor" /></FormControl> <FormLabel htmlFor="role-mentor" className="font-normal cursor-pointer">Mentor (Offering Guidance)</FormLabel> </FormItem> </RadioGroup></FormControl> <FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="fullName" render={({ field }) => ( <FormItem> <FormLabel>Full Name*</FormLabel> <FormControl><Input placeholder="E.g., Ada Lovelace" {...field} /></FormControl> <FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="linkedinProfile" render={({ field }) => ( <FormItem> <FormLabel>LinkedIn Profile URL (Optional)</FormLabel> <FormControl><Input placeholder="https://www.linkedin.com/in/yourprofile" {...field} /></FormControl> <FormDescription>Share your LinkedIn profile if you have one.</FormDescription><FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="location" render={({ field }) => ( <FormItem> <FormLabel>Current Location (City, Country)*</FormLabel> <FormControl><Input placeholder="E.g., London, UK" {...field} /></FormControl> <FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="careerStage" render={({ field }) => ( <FormItem> <FormLabel>Current Career/Education Stage*</FormLabel> <Select onValueChange={field.onChange} defaultValue={field.value}> <FormControl><SelectTrigger><SelectValue placeholder="Select your stage" /></SelectTrigger></FormControl> <SelectContent>{careerStageOptions.map(opt => <SelectItem key={opt.id} value={opt.id}>{opt.label}</SelectItem>)}</SelectContent> </Select> <FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="industries" render={() => ( <FormItem> <div className="mb-2"><FormLabel className="text-base font-semibold">Industries of Interest/Expertise*</FormLabel> <FormDescription>Select all that apply.</FormDescription></div> <div className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-3">{industriesData.map((item) => ( <FormField key={item.id} control={form.control} name="industries" render={({ field }) => ( <FormItem className="flex items-center space-x-2 space-y-0"> <FormControl><Checkbox checked={field.value?.includes(item.id)} onCheckedChange={(checked) => field.onChange( checked ? [...(field.value || []), item.id] : (field.value || []).filter((id) => id !== item.id) )}/></FormControl> <FormLabel className="text-sm font-normal cursor-pointer">{item.label}</FormLabel> </FormItem> )} /> ))}</div> <FormMessage /> </FormItem>)} />
                    <FormField control={form.control} name="languages" render={() => ( <FormItem> <div className="mb-2"><FormLabel className="text-base font-semibold">Languages Spoken*</FormLabel> <FormDescription>Select all you are proficient in.</FormDescription></div> <div className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-3">{languagesData.map((item) => ( <FormField key={item.id} control={form.control} name="languages" render={({ field }) => ( <FormItem className="flex items-center space-x-2 space-y-0"> <FormControl><Checkbox checked={field.value?.includes(item.id)} onCheckedChange={(checked) => field.onChange( checked ? [...(field.value || []), item.id] : (field.value || []).filter((id) => id !== item.id) )}/></FormControl> <FormLabel className="text-sm font-normal cursor-pointer">{item.label}</FormLabel> </FormItem> )} /> ))}</div> <FormMessage /> </FormItem>)} />
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button type="button" onClick={handleNextStep} className="bg-pink-500 hover:bg-pink-600 text-white"> Next <ArrowRight className="ml-2 h-4 w-4" /> </Button>
                  </CardFooter>
                </Card>
              )}

              {/* Step 2: Goals & Needs */}
              {step === 2 && (
                 <Card className="shadow-lg">
                   <CardHeader> <CardTitle>Step 2: Goals & Needs</CardTitle> <CardDescription>What are you looking to achieve or offer?</CardDescription> </CardHeader>
                   <CardContent className="space-y-6">
                     <FormField control={form.control} name="shortTermGoals" render={({ field }) => ( <FormItem> <FormLabel>Short-Term Goals (next 6-12 months)*</FormLabel> <FormControl><Textarea placeholder="E.g., Improve my public speaking skills, find a new job in tech, learn about product management..." {...field} rows={4} /></FormControl> <FormMessage /> </FormItem>)} />
                     <FormField control={form.control} name="longTermGoals" render={({ field }) => ( <FormItem> <FormLabel>Long-Term Aspirations (5+ years)*</FormLabel> <FormControl><Textarea placeholder="E.g., Become a CTO, start my own non-profit, write a book..." {...field} rows={4} /></FormControl> <FormMessage /> </FormItem>)} />
                     <FormField control={form.control} name="helpAreas" render={() => ( <FormItem> <div className="mb-2"><FormLabel className="text-base font-semibold">Key Areas for Mentorship*</FormLabel> <FormDescription>Select areas you're seeking help in or can provide guidance on.</FormDescription></div> <div className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-3">{helpAreasData.map((item) => ( <FormField key={item.id} control={form.control} name="helpAreas" render={({ field }) => ( <FormItem className="flex items-center space-x-2 space-y-0"> <FormControl><Checkbox checked={field.value?.includes(item.id)} onCheckedChange={(checked) => field.onChange( checked ? [...(field.value || []), item.id] : (field.value || []).filter((id) => id !== item.id) )}/></FormControl> <FormLabel className="text-sm font-normal cursor-pointer">{item.label}</FormLabel> </FormItem> )} /> ))}</div> <FormMessage /> </FormItem>)} />
                   </CardContent>
                   <CardFooter className="flex justify-between">
                     <Button type="button" variant="outline" onClick={handlePrevStep}> <ArrowLeft className="mr-2 h-4 w-4" /> Back </Button>
                     <Button type="button" onClick={handleNextStep} className="bg-pink-500 hover:bg-pink-600 text-white"> Next <ArrowRight className="ml-2 h-4 w-4" /> </Button>
                   </CardFooter>
                 </Card>
              )}

              {/* Step 3: Resume Upload */}
              {step === 3 && (
                 <Card className="shadow-lg">
                   <CardHeader> <CardTitle>Step 3: Resume Upload</CardTitle>
                     <CardDescription>
                       {form.getValues("role") === "mentee" ? "Mentees: Please upload your resume (PDF, DOC, or DOCX, max 5MB)." : "Mentors: Resume upload is optional but can help us understand your background."}
                     </CardDescription>
                   </CardHeader>
                   <CardContent className="space-y-6">
                     <FormField control={form.control} name="resume"
                        render={({ field: { onBlur, name, ref }}) => (
                         <FormItem>
                           <FormLabel htmlFor="resume-upload-input" className="sr-only">Resume File</FormLabel>
                           <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-300 p-8 text-center hover:border-pink-400 transition-colors">
                             <FileUp className="h-10 w-10 text-gray-400 mb-3" />
                             <p className="text-sm font-medium text-gray-600 mb-1">
                               {resumeFile ? resumeFile.name : "Drag & drop or click to upload resume"}
                             </p>
                             <p className="text-xs text-gray-500 mb-3">PDF, DOC, DOCX (MAX. 5MB)</p>
                             <FormControl>
                               <Input
                                 type="file"
                                 id="resume-upload-input"
                                 className="hidden"
                                 accept=".pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                 onChange={handleFileChange}
                                 onBlur={onBlur}
                                 name={name}
                                 ref={ref}
                               />
                             </FormControl>
                             <Button type="button" variant="outline" className="text-sm" onClick={() => document.getElementById("resume-upload-input")?.click()}>
                               {resumeFile ? "Change Resume" : "Browse Files"}
                             </Button>
                           </div>
                           <FormMessage />
                         </FormItem>
                       )}
                     />
                     <p className="text-xs text-gray-500 text-center pt-2">
                       Your resume helps us understand your background for better matching.
                     </p>
                   </CardContent>
                   <CardFooter className="flex justify-between">
                     <Button type="button" variant="outline" onClick={handlePrevStep}> <ArrowLeft className="mr-2 h-4 w-4" /> Back </Button>
                     <Button type="submit" className="bg-pink-500 hover:bg-pink-600 text-white"
                       disabled={isSubmitting || (form.getValues("role") === "mentee" && !resumeFile && step === 3 && formSchema.shape.resume.isOptional() === false ) }> {/* Logic to disable submit if resume is mandatory for mentee */}
                       {isSubmitting ? ( <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...</> ) : ( "Complete Profile & Find Matches" )}
                     </Button>
                   </CardFooter>
                 </Card>
              )}
            </form>
          </Form>
        </div>
      </main>
    </div>
  );
}